public class Pembayaran {

    public String barang;
    public double total;
    public double harga;
    public double jumlah;

    public Pembayaran(String barang, double harga, double jumlah) {
        this.barang = barang;
        this.harga = harga;
        this.jumlah = jumlah;
        this.total = harga * jumlah;
    }

    //getter and setter

    public String getBarang() {
        return barang;
    }

    public void setBarang(String barang) {
        this.barang = barang;
    }

    public double getHarga() { return harga; }

    public void setHarga(double harga) {
        this.harga = harga;
    }

    public double getJumlah() {
        return jumlah;
    }

    public void setJumlah(double jumlah) {
        this.jumlah = jumlah;
    }


    //to string
    @Override
    public String toString() {
        return "Pembayaran {" +
                "barang='" + barang + '\'' +
                ", harga=" + harga +
                ", jumlah=" + jumlah +
                ", total=" + total  +
                '}';
    }

    public void countDiscount(){
        double discount;
        double awal = total;

        if (awal >= 500000 && awal < 1000000) {
            discount = awal * 0.10;
            total = awal - discount;
            System.out.println("Anda mendapat diskon 10%");
        }
        else if (awal >= 1000000){
            discount = awal * 0.30;
            total = awal - discount;
            System.out.println("Anda mendapat diskon 30%");
        }
        else {
            System.out.println("Anda tidak mendapat diskon");
        }
    }
}