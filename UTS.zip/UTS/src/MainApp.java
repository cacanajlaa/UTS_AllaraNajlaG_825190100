import java.util.Scanner;
public class MainApp {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        String barang;
        double harga;
        double jumlah;
        System.out.println("Selamat Datang di Toko kami");
        System.out.println("Masukkan Barang: ");
        barang = s.nextLine();
        System.out.println("Masukkan Harga: ");
        harga = s.nextDouble();
        System.out.println("Masukkan Jumlah: ");
        jumlah = s.nextDouble();

        Pembayaran a = new Pembayaran(barang, harga, jumlah);
        System.out.println("Total: " + a.total);
        a.countDiscount();
        System.out.println("Total: " + a.total);
        System.out.println(a.toString());
    }
}
